1) show all users in Manager users in adminPanel  name, email,active/block=>clicked,view user,edit user,email verified,blocked users list in blocked users
2) send Email
3) send Android Notification 
	=> send to All 
		=>couse added
		=>topic Added
		=>verification notification

	=> send to user
